<a href="index.php/code">Code</a><br>
<a href="index.php/style">Style</a>