

<div class="row">
	<div class="col-xs-4 col-xs-offset-4">
		<h1>inloggen</h1>
		<form method="post" action="" name="inloggen">
			<div class="form-group">
				<label for="gebruikersnaam">Gebruikersnaam.</label>
				<input type="text" class="form-control" name="Username" />
			</div>
			<div class= "form-group">
				<label for="wachtwoord">Wachtwoord.</label>
				<input type="password" class="form-control" name="Password" />
			</div>
			<input type="submit" class="btn btn-default" name="Inloggen" value="inloggen" />
		</form>
	</div>
</div>